<?php
/**
 * Maps all theme shortcodes to Visual Composer
 *
 * 
 * @package    Auxin
 * @license    LICENSE.txt
 * @author     
 * @link       http://phlox.pro/
 * @copyright  (c) 2010-2019 
 */

