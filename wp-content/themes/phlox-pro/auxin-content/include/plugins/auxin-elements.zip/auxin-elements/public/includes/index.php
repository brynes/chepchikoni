<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die('No Naughty Business Please !');
}

include 'class-auxels-frontend-assets.php';
include 'templates-post.php';
